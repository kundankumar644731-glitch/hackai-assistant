# ⚡ HACK.AI — Deployment Guide

## 📁 Project Structure
```
hackai-project/
├── server.js          ← Node.js backend (API proxy)
├── package.json       ← Dependencies
├── .env.example       ← Environment variables template
└── public/
    └── index.html     ← Frontend (UI)
```

---

## 🚀 FREE Deployment on Render.com (Recommended)

### Step 1 — GitHub pe upload karo
1. github.com pe jaao → New Repository → "hackai-assistant"
2. Ye saare files upload karo
3. `.env.example` ka naam change karo → `.env` (aur apni key daalo)
   ⚠️ `.env` file GitHub pe mat daalna! (API key leak hogi)

### Step 2 — Render pe deploy karo
1. **render.com** pe free account bana
2. "New Web Service" click karo
3. Apna GitHub repo connect karo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. "Environment Variables" mein jaao:
   - Key: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-apni-key-yahan`
6. Deploy karo! 🎉

### Step 3 — Live link mil jayegi!
```
https://hackai-assistant.onrender.com
```

---

## 💻 Local Test Karna Hai?

```bash
# 1. Dependencies install karo
npm install

# 2. .env file banao
cp .env.example .env
# Ab .env mein apni API key daalo

# 3. Server start karo
npm start

# 4. Browser mein kholo
# http://localhost:3000
```

---

## 🔑 Anthropic API Key Kahan Se Milegi?
1. console.anthropic.com pe jaao
2. Free account banao
3. "API Keys" → "Create Key"
4. Copy karo aur .env mein daalo

**Free credits milte hain — kafi kaam chalega!** ✅
